var boxEle = document.body.querySelector(".box");

var numberOne = prompt("First number");

var numberTwo = prompt("Second number");

var x = numberOne;

var y = numberTwo;

var z = x + y;

boxEle.innerHTML=numberOne+numberTwo;

boxEle.innerHTML=userInput;